def celcius_ke_fahrenheit(celcius):
    return (celcius * 9/5) + 32

def fahrenheit_ke_celcius(fahrenheit):
    return (fahrenheit - 32) * 5/9

def kilometer_ke_mil(kilometer):
    return kilometer * 0.621371

# Uji fungsi konversi
print("\nKonversi:")
print("Celcius ke Fahrenheit:", celcius_ke_fahrenheit(100))  # Output: 212.0
print("Fahrenheit ke Celcius:", fahrenheit_ke_celcius(32))  # Output: 0.0
print("Kilometer ke Mil:", kilometer_ke_mil(10))  # Output: 6.21371