def luas_persegi_panjang(panjang, lebar):
    return panjang * lebar

def keliling_persegi_panjang(panjang, lebar):
    return 2 * (panjang + lebar)

def apakah_persegi(panjang, lebar):
    if panjang == lebar:
        return True
    else:
        return False
    
# Uji fungsi bentuk
print("\nBentuk:")
print("Luas Persegi Panjang:", luas_persegi_panjang(5, 3))  # Output: 15
print("Keliling Persegi Panjang:", keliling_persegi_panjang(5, 3))  # Output: 16
print("Apakah Persegi:", apakah_persegi(5, 5))  # Output: True