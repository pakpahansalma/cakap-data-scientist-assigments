import random

def acak_integer(min_value, max_value):
    return random.randint(min_value, max_value)

def acak_pilihan(pilihan):
    return random.choice(pilihan)

def acak_genap(min_value, max_value):
    num = random.randint(min_value, max_value)
    if num % 2 != 0:  # Generate again if it's odd
        num += 1
    return num

# Uji fungsi acak
print("\nAcak:")
print("Acak Integer:", acak_integer(1, 10))  # Random integer between 1 and 10
print("Acak Pilihan:", acak_pilihan(['apel', 'pisang', 'ceri']))  # Random choice from list
print("Acak Genap:", acak_genap(1, 10))  # Random even integer between 1 and 10