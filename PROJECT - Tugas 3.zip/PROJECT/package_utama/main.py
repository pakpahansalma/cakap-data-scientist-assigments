from modul1.aritmetika import tambah, kurang, kali
from modul1.util_string import ubah_ke_huruf_besar, hitung_vokal, apakah_palindrom
from modul1.util_daftar import panjang_daftar, jumlah_daftar, filter_nomor_genap
from modul2.perbandingan import lebih_besar, cari_max, hitung_nomor_positif
from modul2.penghitung import hitung_sampai, hitung_mundur, hitung_genap
from modul2.salam import sapa, selamat_tinggal, sapa_banyak
from modul3.bentuk import luas_persegi_panjang, keliling_persegi_panjang, apakah_persegi
from modul3.konversi import celcius_ke_fahrenheit, fahrenheit_ke_celcius, kilometer_ke_mil
from modul3.acak import acak_integer, acak_pilihan, acak_genap

# Uji fungsi aritmetika
print("Aritmetika:")
print("Tambah:", tambah(5, 3))  # Output: 8
print("Kurang:", kurang(5, 3))  # Output: 2
print("Kali:", kali(4, 3))  # Output: 12

# Uji fungsi string
print("\nUtil String:")
print("Ubah ke Huruf Besar:", ubah_ke_huruf_besar("hello"))  
print("Hitung Vokal:", hitung_vokal("hello world"))  
print("Apakah Palindrom:", apakah_palindrom("madam"))  

# Uji fungsi daftar
print("\nUtil Daftar:")
print("Panjang Daftar:", panjang_daftar([1, 2, 3, 4]))  
print("Jumlah Daftar:", jumlah_daftar([1, 2, 3, 4])) 
print("Nomor Genap:", filter_nomor_genap([1, 2, 3, 4, 5, 6]))  

# Uji fungsi perbandingan
print("\nPerbandingan:")
print(lebih_besar(5, 3))  
print("Max:", cari_max([1, 2, 3, 4, 5])) 
print("Hitung Nomor Positif:", hitung_nomor_positif([-1, 0, 1, 2]))  

# Uji fungsi penghitung
print("\nPenghitung:")
hitung_sampai(5) 
hitung_mundur(5)  
print("Hitung Genap:", hitung_genap(10))  

# Uji fungsi salam
print("\nSalam:")
print(sapa("Alice"))  
print(selamat_tinggal("Bob")) 
print(sapa_banyak(["Alice", "Bob"]))  

# Uji fungsi bentuk
print("\nBentuk:")
print("Luas Persegi Panjang:", luas_persegi_panjang(5, 3))  
print("Keliling Persegi Panjang:", keliling_persegi_panjang(5, 3))  
print("Apakah Persegi:", apakah_persegi(5, 5)) 

# Uji fungsi konversi
print("\nKonversi:")
print("Celcius ke Fahrenheit:", celcius_ke_fahrenheit(100))  
print("Fahrenheit ke Celcius:", fahrenheit_ke_celcius(32)) 
print("Kilometer ke Mil:", kilometer_ke_mil(10))  

# Uji fungsi acak
print("\nAcak:")
print("Acak Integer:", acak_integer(1, 10)) 
print("Acak Pilihan:", acak_pilihan(['apel', 'pisang', 'ceri'])) 
print("Acak Genap:", acak_genap(1, 10)) 