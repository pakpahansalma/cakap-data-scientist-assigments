def lebih_besar(a, b):
    if a > b:
        return f"{a} lebih besar dari {b}"
    elif a < b:
        return f"{b} lebih besar dari {a}"
    else:
        return "Keduanya sama"
    
def cari_max(angka):
    max_num = angka[0]
    for num in angka:
        if num > max_num:
            max_num = num
    return max_num

def hitung_nomor_positif(angka):
    hitung = 0
    for num in angka:
        if num > 0:
            hitung += 1
    return hitung

# Uji fungsi perbandingan
print("\nPerbandingan:")
print(lebih_besar(5, 3))  # Output: "5 lebih besar dari 3"
print("Max:", cari_max([1, 2, 3, 4, 5]))  # Output: 5
print("Hitung Nomor Positif:", hitung_nomor_positif([-1, 0, 1, 2]))  # Output: 2
