def sapa(nama):
    if nama:
        return f"Halo, {nama}!"
    else:
        return "Halo, orang asing!"

def selamat_tinggal(nama):
    if nama:
        return f"Sampai jumpa, {nama}!"
    else:
        return "Sampai jumpa, orang asing!"

def sapa_banyak(nama_list):
    sapaan = []
    for nama in nama_list:
        sapaan.append(sapa(nama))
    return sapaan

# Uji fungsi salam
print("\nSalam:")
print(sapa("Alice"))  # Output: "Halo, Alice!"
print(selamat_tinggal("Bob"))  # Output: "Sampai jumpa, Bob!"
print(sapa_banyak(["Alice", "Bob"]))  # Output: ["Halo, Alice!", "Halo, Bob!"]