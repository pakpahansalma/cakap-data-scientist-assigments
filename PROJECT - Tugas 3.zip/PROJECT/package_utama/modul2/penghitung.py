def hitung_sampai(n):
    for i in range(1, n + 1):
        print(i)

def hitung_mundur(n):
    for i in range(n, 0, -1):
        print(i)

def hitung_genap(n):
    hitung = 0
    for i in range(1, n + 1):
        if i % 2 == 0:
            hitung += 1
    return hitung

# Uji fungsi penghitung
print("\nPenghitung:")
hitung_sampai(5)  # Output: 1 2 3 4 5
hitung_mundur(5)  # Output: 5 4 3 2 1
print("Hitung Genap:", hitung_genap(10))  # Output: 5