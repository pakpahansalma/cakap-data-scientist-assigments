def panjang_daftar(lst):
    hitung = 0
    for _ in lst:
        hitung += 1
    return hitung

def jumlah_daftar(lst):
    total = 0
    for num in lst:
        total += num
    return total

def filter_nomor_genap(lst):
    genap = []
    for num in lst:
        if num % 2 == 0:
            genap.append(num)
    return genap

print("\nUtil Daftar:")
print("Panjang Daftar:", panjang_daftar([1, 2, 3, 4]))  # Output: 4
print("Jumlah Daftar:", jumlah_daftar([1, 2, 3, 4]))  # Output: 10
print("Nomor Genap:", filter_nomor_genap([1, 2, 3, 4, 5, 6]))  # Output: [2, 4, 6]