def ubah_ke_huruf_besar(s):
    hasil = ""
    for char in s:
        if char.islower():
            hasil += char.upper()
        else:
            hasil += char
    return hasil

def hitung_vokal(s):
    vokal = "aeiouAEIOU"
    hitung = 0
    for char in s:
        if char in vokal:
            hitung += 1
    return hitung

def apakah_palindrom(s):
    s_reverse = s[::-1]
    if s == s_reverse:
        return True
    else:
        return False
    
print("\nUtil String:")
print("Ubah ke Huruf Besar:", ubah_ke_huruf_besar("hello"))  # Output: "HELLO"
print("Hitung Vokal:", hitung_vokal("hello world"))  # Output: 3
print("Apakah Palindrom:", apakah_palindrom("madam"))  # Output: True
