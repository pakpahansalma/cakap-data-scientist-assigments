def tambah(a, b):
    return a + b

def kurang(a, b):
    if a >= b:
        return a - b
    else:
        return b - a

def kali(a, b):
    hasil = 0
    for _ in range(b):
        hasil += a
    return hasil

print("Aritmetika:")
print("Tambah:", tambah(5, 3))  # Output: 8
print("Kurang:", kurang(5, 3))  # Output: 2
print("Kali:", kali(4, 3))  # Output: 12