# staf

from karyawan import Karyawan

class Staf(Karyawan):
    def __init__(self, nama, gaji, posisi):
        super().__init__(nama, gaji)  # Memanggil konstruktor kelas induk
        self.posisi = posisi

    def info(self):
        return f"{super().info()}, Posisi: {self.posisi}"

    def tugas(self):
        return "Staf melaksanakan tugas sesuai posisi."