# karyawan

class Karyawan:
    def __init__(self, nama, gaji):
        self._nama = nama              # Enkapsulasi
        self._gaji = gaji              # Enkapsulasi

    def info(self):
        return f"Nama: {self._nama}, Gaji: {self._gaji}"

    def tugas(self):
        return "Karyawan melaksanakan tugas umum."