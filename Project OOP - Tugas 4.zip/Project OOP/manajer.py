# manajer

from karyawan import Karyawan

class Manajer(Karyawan):
    def __init__(self, nama, gaji, departemen):
        super().__init__(nama, gaji)  # Memanggil konstruktor kelas induk
        self.departemen = departemen

    def info(self):
        return f"{super().info()}, Departemen: {self.departemen}"

    def tugas(self):
        return "Manajer mengelola tim dan proyek."
