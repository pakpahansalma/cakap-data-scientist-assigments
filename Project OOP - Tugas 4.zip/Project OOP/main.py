# main
from manajer import Manajer
from staf import Staf

def main():
    karyawan1 = Manajer("Salma", 9000000, "HR")
    karyawan2 = Staf("Wike", 5000000, "Administrasi")

    # Menggunakan polimorfisme
    for karyawan in (karyawan1, karyawan2):
        print(karyawan.info())
        print(karyawan.tugas())

if __name__ == "__main__":
    main()